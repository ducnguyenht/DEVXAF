﻿Folder Description

The "Controllers" project folder is intended for storing platform-agnostic Controller classes 
that can change the default XAF application flow and add new features.


Relevant Documentation

Extend Functionality
http://help.devexpress.com/#Xaf/CustomDocument2623

Controller Class
http://help.devexpress.com/#Xaf/clsDevExpressExpressAppControllertopic

ViewController Class
http://help.devexpress.com/#Xaf/clsDevExpressExpressAppViewControllertopic

WindowController Class
http://help.devexpress.com/#Xaf/clsDevExpressExpressAppWindowControllertopic
