﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestLog.RDS;
using Db = TestLog.RDS.DucTestMySqlEntities;
namespace DMSAuditTrail.Business.ORM.Helper
{
    public static class RDSAuditTrail
    {

        internal static List<AuditTrail> getAuditTrails(Guid Oid)
        {
            Db db = new Db();
            string oid = Oid.ToString();
            var auditTrails = db.AuditTrails.Where(o => o.Oid == oid).OrderByDescending(o => o.ChangedOn).ToList();
            db.Dispose();
            return auditTrails;
        }

        //internal static List<AuditTrail> GetAllPageType()
        //{
        //    try
        //    {
        //        DB db = new DB();
        //        db.AuditTrails.
        //        return db.AuditTrails.;
        //    }
        //    catch (Exception e)
        //    {
        //        throw e;

        //    }
        //}
    }
}
