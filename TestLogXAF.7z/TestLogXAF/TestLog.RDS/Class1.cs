﻿using System;
using System.Collections.Generic;
using System.Linq;
using Db = TestLog.RDS.DucTestMySqlEntities;
namespace TestLog.RDS
{
    public class Class1
    {
        public void InsertData(Guid Oid, string ChangedBy, string Data)
        {
            Db db = new Db();
            AuditTrail h = new AuditTrail();
            h.Oid = Oid.ToString();
            h.ChangedBy = ChangedBy;
            h.Data = Data;
            h.ChangedOn = DateTime.Now;
            db.AuditTrails.Add(h);
            db.SaveChanges();
            db.Dispose();
        }
        public List<AuditTrail> getHistory(Guid Oid)
        {
            Db db = new Db();
            string oid = Oid.ToString();
            var auditTrails = db.AuditTrails.Where(o => o.Oid == oid).OrderByDescending(o => o.ChangedOn).ToList();
            db.Dispose();
            return auditTrails;
        }

    }
}
//public void InsertHistory(Guid Oid, string ChangedBy, string Data)
//{
//    Db db = new Db();
//    TestHistory h = new TestHistory();
//    //h.Oid = Oid.ToString();
//    h.ChangedBy = ChangedBy;
//    // h.ChangedOn = DateTime.Now;
//    h.Description = "asdfsdf";//Data;
//    db.TestHistories.Add(h);
//    db.SaveChanges();
//}